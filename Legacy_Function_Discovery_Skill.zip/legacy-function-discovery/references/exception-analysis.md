# Exception Analysis

不要只写 Happy Path。

覆盖：
validation、not found、duplicate、invalid status、permission、DB error、timeout、file missing、format error、duplicate file、external failure、retry、rollback、partial completion、restart/recovery。

每项明确：
user result / DB result / file result / external result / transaction / recovery。

不要自行假设 rollback 或 retry，必须有证据。
