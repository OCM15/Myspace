# Business vs Implementation Classification

Decision tree：

```text
Carries business information?
 ├─ YES → BUSINESS_DATA / INPUT / OUTPUT
 └─ NO
    ↓
Represents business state/rule?
 ├─ YES → BUSINESS_STATE / RULE
 └─ NO
    ↓
Externally required interface?
 ├─ YES → BUSINESS_INTERFACE
 └─ NO
    ↓
Technical processing control?
 ├─ YES → TECHNICAL_TRIGGER / CONTROL / TEMPORARY
 └─ NO
    ↓
Source/framework-specific?
 ├─ YES → IMPLEMENTATION_DETAIL
 └─ NO → UNKNOWN
```

三个测试：
1. Business Necessity Test
2. Replaceability Test
3. Content Dependency Test

Trigger 示例：
`complete.dat` 无业务内容，仅通知后续Batch开始 → TECHNICAL_TRIGGER。
`settlement.csv` 被下游消费业务数据 → BUSINESS_INTERFACE；CSV只是当前实现格式。
