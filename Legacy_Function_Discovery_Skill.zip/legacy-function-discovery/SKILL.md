---
name: legacy-function-discovery
description: Reverse-engineer a legacy system function into an implementation-independent functional specification. Use before migration/refactoring when completeness, DB/File/I-F behavior, triggers, permissions, validations, exceptions, and hidden dependencies matter.
---

# Legacy Function Discovery Skill

## 1. Mission

从 Legacy Source Code 逆向整理一个功能，输出：
1. 不依赖旧源码即可理解的功能规格；
2. 可以据此设计新实现的规格；
3. 可以据此生成 Acceptance/Migration Test 的规格；
4. 明确必须保持的业务行为；
5. 明确业务需求与技术实现手段的区别。

## 2. Highest-Priority Rules

### 2.1 Preserve business behavior, not implementation

目标链路：

```text
Legacy Source
  ↓
Evidence
  ↓
Business / Functional Model
  ↓
Implementation Mapping
  ↓
Independent Functional Specification
```

不要把 Class / Method / DAO / JSP / Framework / Mapper 的调用图直接当成业务流程。

### 2.2 Source existence does not prove business necessity

每个重要对象分类为：

- BUSINESS_DATA
- BUSINESS_RULE
- BUSINESS_STATE
- BUSINESS_INPUT
- BUSINESS_OUTPUT
- BUSINESS_INTERFACE
- TECHNICAL_TRIGGER
- TECHNICAL_CONTROL
- TECHNICAL_TEMPORARY
- IMPLEMENTATION_DETAIL
- UNKNOWN

证据不足必须使用 UNKNOWN，不得猜测。

### 2.3 Replaceability Test

问：

> 如果换掉当前技术手段，业务目的是否仍然成立？

如果成立，则当前手段大概率属于实现方式。

例如：

```text
Business requirement:
前处理成功后通知后续处理开始。

Current implementation:
生成 /xxx/complete.dat。

Classification:
TECHNICAL_TRIGGER
```

除非证据证明 complete.dat 本身是外部业务接口，否则不能把“必须生成 complete.dat”写成业务需求。

### 2.4 Explicit resource specification

DB/File/MQ/API/I-F 必须在有证据时明确：
- resource name
- operation
- columns/fields
- mapping
- conditions
- joins
- ordering
- transaction
- encoding/format
- error behavior
- trigger semantics
- timing
- dependency

不要只写“更新DB”“生成文件”。

## 3. Five-Pass Discovery

### Pass 1 — Entry Analysis

分析：
- screen/menu
- REST/API
- batch/scheduler
- file arrival
- MQ/event
- internal/external invocation

记录 actor、entry condition、input、permission、precondition。

### Pass 2 — Forward Flow

```text
Input → Validation → Business Decision → Calculation → DB/File/API/MQ → Output
```

所有重要分支都记录 success/failure。

### Pass 3 — Reverse Dependency Analysis

从资源反向追踪：
- Table → SQL → DAO/Mapper → Service → Function
- Output File → writer → caller → completion purpose
- Trigger File → watcher/batch → reason
- API/MQ → consumer → purpose
- Status field → readers/writers → business meaning

### Pass 4 — Exception / Negative Path Analysis

明确：
validation failure、not found、duplicate、invalid status、permission、DB error、timeout、file missing、format error、duplicate file、external failure、retry、rollback、partial completion、restart/recovery。

记录：
user result、DB effect、file effect、external effect、transaction effect、downstream effect。

### Pass 5 — Data Flow Analysis

```text
Input
 → validation
 → transformation
 → calculation
 → DB/API/File
 → output
```

记录 source、destination、transformation、default、null、format、validation、business meaning。

## 4. Business vs Implementation

使用三个测试：

### Business Necessity Test
没有它，业务目的是否消失？

### Replaceability Test
是否可以换成另一技术手段而不改变业务目的？

### Content Dependency Test
业务依赖其内容，还是只依赖其存在/时机？

例：

| 对象 | 分类 |
|---|---|
| TRADE_INFO.AMOUNT | BUSINESS_DATA |
| APPROVAL_STATUS | BUSINESS_STATE |
| settlement.csv 被外部系统消费 | BUSINESS_INTERFACE |
| complete.dat 只用于唤醒 Batch | TECHNICAL_TRIGGER |
| .lock 防并发 | TECHNICAL_CONTROL |
| 临时CSV处理后删除 | TECHNICAL_TEMPORARY |
| Java DAO类名 | IMPLEMENTATION_DETAIL |

### Trigger Rule

如果文件只是通知：

```text
Business:
前处理正常完成后，通知后续处理。

Implementation:
创建 complete.dat。

Classification:
TECHNICAL_TRIGGER
```

如果文件包含下游真正需要的业务数据：

```text
Business:
向下游交付结算数据。

Implementation:
生成 settlement.csv。

Classification:
BUSINESS_INTERFACE
Format:
CSV
```

## 5. Database Requirements

发现 DB 时记录：
- DB type
- schema/owner
- table/view
- operation
- selected/inserted/updated/deleted columns
- WHERE
- JOIN
- GROUP/HAVING（如有）
- ORDER BY（如影响行为）
- parameter mapping
- NULL/default
- result cardinality
- update count behavior
- transaction/commit/rollback
- locking/concurrency（可观察时）
- business meaning

示例：

```sql
UPDATE TRADE_INFO
SET AMOUNT = :amount,
    UPDATED_BY = :userId,
    UPDATED_AT = :now
WHERE TRADE_ID = :tradeId
  AND STATUS = 'OPEN'
```

同时分开写：

```text
Business requirement:
更新指定且处于OPEN状态的交易金额。

Current DB implementation:
UPDATE TRADE_INFO ... WHERE TRADE_ID=:tradeId AND STATUS='OPEN'
```

如果迁移必须保持现有DB contract，则具体 table/column/condition 是 mandatory resource constraint。

## 6. File I/O Requirements

记录：
- input/output
- business/technical classification
- file name/pattern
- location
- encoding
- line ending
- format/delimiter
- header
- field order
- field name/type/length
- required/optional
- null/empty
- creation timing
- duplicate/overwrite
- completion/error marker
- archive/move/delete
- partial-file handling
- error handling
- trigger semantics

不要默认“生成的文件”就是业务输出。

## 7. External I/F

记录：
business purpose、sender/receiver、trigger、request/message、mapping、authentication（有行为影响时）、timeout、retry、response/ack、error mapping、transaction relationship、downstream purpose。

始终区分：
- Business contract：必须发生什么
- Current transport：现在怎么做到

## 8. Functional Specification

最终至少包含：

1. Function Overview
2. Business Purpose
3. Actors / Users
4. Preconditions
5. Permissions
6. Inputs
7. Outputs
8. Business Rules
9. Main Flow
10. Alternative Flows
11. Validation Rules
12. Calculations / Transformations
13. Database Specification
14. File I/O Specification
15. External Interface Specification
16. Trigger / Control Mechanisms
17. Transaction / Consistency
18. Exception / Error Handling
19. Recovery / Retry
20. Observable Results
21. Business/Implementation Classification
22. Traceability
23. Acceptance Criteria
24. Unknowns / Open Questions

## 9. Source-Code Blackout Test

完成草稿后，假设源码完全不可用，检查：

- 能否说明功能目的？
- 能否知道用户/权限？
- 能否知道输入输出？
- 能否知道所有重要规则和分支？
- 能否知道 DB table/column/condition？
- 能否知道 File format/field/error？
- 能否知道外部 I/F？
- 能否知道 trigger 的业务目的？
- 能否知道异常/rollback/retry？
- 能否区分业务要求与旧技术实现？
- 能否由此重新实现并测试？

不能回答的项目回到源码补证据。

## 10. Evidence Discipline

每个重要设计项应有 evidence：
- source file / class / method
- SQL
- configuration
- test
- interface definition
- runtime/log evidence
- human confirmation

最终业务设计不要依赖源码名称，但单独维护 traceability。

## 11. Completion Criteria

只有在以下条件全部满足时才算完成：
- normal/alternative/error flows covered
- important fields traced
- DB explicit
- File explicit
- External I/F explicit
- Trigger/control classified
- business/implementation separated
- unknowns explicit
- acceptance criteria derivable
- source-code-independent review passed
