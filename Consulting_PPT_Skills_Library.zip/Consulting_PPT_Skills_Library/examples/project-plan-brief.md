# Example Brief — Project Plan

- Audience: Project Steering Committee
- Purpose: Align on scope, schedule, governance, and major risks
- Topic: Legacy Java web system modernization
- Language: Japanese
- Length: 8–10 slides
- Title strategy: Hybrid
- Visual direction: Neutral consulting style; use corporate theme if available
- Must include: Project overview, scope, workstreams, overall schedule, organization chart, key milestones, risks, decisions required
- Data status: Dates and owners must come from the project source; unknown values must be marked TBD
- Deliverable: Editable PowerPoint
