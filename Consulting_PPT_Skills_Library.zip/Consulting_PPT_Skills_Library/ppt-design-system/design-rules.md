# Design Rules — Default Baseline

此文件用于项目级统一规范。公司正式规范优先于以下默认值。

## Canvas
- Aspect ratio: 16:9
- Background: white / very light neutral
- Margins: consistent on all slides
- Grid: align titles, cards, diagrams and footers to common guides

## Typography
- One primary font family
- Title: 28–36 pt (guideline)
- Body: 18–24 pt (guideline)
- Source/footnote: 9–12 pt if legible
- Avoid automatic shrink-to-fit as a first resort

## Color semantics
- Primary text: dark charcoal/navy
- Main accent: blue or teal
- Neutral: light gray
- Status: red = critical, amber = attention, green = on track only if the organization agrees
- Never rely on color alone; include labels/icons/text

## Shape rules
- Prefer a small, consistent set of shapes: rectangle, rounded rectangle, circle, line, arrow.
- Standardize corner radius, line weight, inner padding and shadow usage.
- Use shapes to encode meaning, not decoration.
- Use the same shape for the same meaning throughout a deck.

## Footer
- Apply company-standard confidentiality, page number, date and source conventions.
- If none are provided, keep footer minimal and consistent.

## Layout density
- One main message per slide.
- Typically 3–5 visual groups.
- If a slide becomes crowded, simplify or split it before reducing font size.
