# File I/O Specification

每个文件记录：
Direction / Business-vs-Technical / Name-Pattern / Location / Encoding / Line Ending / Format / Header / Fields / Order / Type / Length / Required / Null / Creation Timing / Duplicate / Completion/Error Marker / Archive/Move/Delete / Partial File / Error / Trigger Semantics。

`complete.dat` 只用于唤醒Batch：
Business = 通知后续处理；Implementation = 生成trigger file。

如果文件本身承载下游需要的业务数据，则分类为 BUSINESS_INTERFACE，而不是简单 Trigger。
