# UI and Workflow Test Skill

## Principle

UI design can change. User capability cannot unintentionally change.

## Test

For each screen verify:
- screen opens
- required functions exist
- fields exist
- editable/read-only state
- validation
- actions
- navigation
- messages
- authorization

## Workflow

Represent a business workflow as actions:

OPEN
INPUT
SELECT
CLICK
CONFIRM
CANCEL
NAVIGATE
SEARCH
VERIFY

Example:

OPEN Register
-> SELECT BUY
-> INPUT amount
-> CLICK Save
-> CONFIRM
-> VERIFY Success

The new UI can use different component types or labels if the semantic business action remains equivalent.

## Playwright

Prefer:

```text
[data-testid="transaction-register"]
[data-action="TRANSACTION_CREATE"]
```

Avoid coordinate-based selectors and fragile generated CSS.

## Screenshots

Use screenshots as evidence, not as the primary equivalence oracle.

Pixel differences are acceptable unless the project explicitly requires visual equivalence.
