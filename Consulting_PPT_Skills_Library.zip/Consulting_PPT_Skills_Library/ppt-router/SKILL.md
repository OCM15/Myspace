---
name: ppt-router
description: 根据受众、目的和交付物，选择合适的企业 PowerPoint 制作流程、页面类型和图解模式。
---

# PPT Router Skill

## 目标
根据演示文稿的目的、受众、决策需求和交付形式，选择适当的制作流程。

## 识别输入
尽可能识别：
- 受众与职级
- 目的：汇报、决策、对齐、调查分析或提案
- 主题、范围和关键问题
- 页数或演讲时长
- 数据、源文件和证据是否可用
- 语言、公司模板、保密要求和交付格式

只询问会实质影响结果的缺失信息；其他情况明确说明假设后继续。

## 场景路由
- 项目目标、范围、WBS、里程碑、资源、依赖关系 → `ppt-project-plan`；页面类型可选 Project Overview、Execution Roadmap、Action Items
- 周报/月报、计划与实际偏差、风险、决策、下一步行动 → `ppt-status-report`；页面类型可选 Project Status Report、KPI Dashboard、Risk & Mitigation、Action Items
- 问题定义、证据、根因、备选方案、纠正措施 → `ppt-issue-analysis`；页面类型可选 Issue Tree / Root Cause、As-Is / To-Be
- 业务/IT 方案、目标架构、方案比较、收益和实施路径 → `ppt-solution-proposal`；页面类型可选 Option Comparison、Recommendation & Decision、Solution Architecture、Cost-Benefit / Business Case
- 说明业务步骤、部门交接、审批或异常路径 → Process Flow（跨部门优先考虑 Swimlane）
- 说明系统间数据、文件、表、接口或消息流 → Data Flow / Interface Mapping
- 说明组织职责、决策权限和会议机制 → Organization & Governance
- 面向管理层快速汇报结论 → Executive Summary

具体页面类型、布局建议和完整性检查统一见 `ppt-slide-type-library/catalog.md`。

所有演示文稿都必须应用：
- `ppt-design-system`
- `ppt-title-strategy`
- `ppt-slide-type-library`
- 根据内容需要使用 `ppt-layout-library`、`ppt-diagram-library` 和 `ppt-visual-component-library`
- 交付前执行 `ppt-quality-check`

## 工作流程
1. 明确演示文稿需要支持的决策或结果。
2. 用一句话定义核心信息。
3. 设计故事线和逐页大纲，并说明每页目的。
4. 为每页选择页面类型和标题模式。
5. 识别所需数据与证据；缺失项要明确标记。
6. 对大型演示文稿或用户要求时，先请用户确认大纲。
7. 使用可用的 PowerPoint 工具或项目脚本生成可编辑文件。
8. 检查内容、数据、布局和渲染。
9. 交付文件，并列出假设、缺口和需要负责人确认的事项。

## 强制规则
- 用户指定的公司模板、标题模式或风格优先，除非与强制公司标准冲突。
- 适当使用结论型标题；避免无意义的通用标题。
- 每页只表达一个主要信息。
- 不得编造事实、项目状态、指标、来源或审批结论。
- 明确区分事实、假设、假说、建议和开放问题。
- 图表/图解必须服务于理解，不得仅为装饰。
- 不强制所有演示文稿使用相同页数或完全相同故事线。
- 保留用户和组织既定的术语。
