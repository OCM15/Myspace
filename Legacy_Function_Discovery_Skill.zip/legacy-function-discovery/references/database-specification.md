# Database Specification

每个 SQL operation 至少记录：
Resource / Operation / Purpose / Tables-Views / Columns / WHERE / JOIN / ORDER / Parameters / NULL-default / Cardinality / Update count / Transaction / Error / Business meaning。

示例：
```sql
SELECT TRADE_ID, TRADE_TYPE, AMOUNT
FROM TRADE_INFO
WHERE TRADE_ID = :tradeId
```

功能解释：
- Input: tradeId
- Output: trade information
- Zero rows: not found
- Multiple rows: uniqueness assumption must be investigated

必须把“业务需求”和“当前DB实现”分开描述。
