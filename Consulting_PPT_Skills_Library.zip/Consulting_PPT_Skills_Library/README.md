# Consulting PPT Skills Library

用于 GitHub Copilot 等支持仓库内 Skills 的 AI 编程助手的企业 PPT 设计与制作规范。目标不是复制某家咨询公司的专有模板，而是建立一套可复用、可维护、风格一致的原创咨询式演示方法。

## 本包包含什么

- `ppt-router/`：根据目标、受众和场景选择制作流程
- `ppt-design-system/`：统一视觉风格与图表规范
- `ppt-project-plan/`：项目计划
- `ppt-status-report/`：项目进度/状态报告
- `ppt-issue-analysis/`：课题与根因分析
- `ppt-solution-proposal/`：业务及 IT 解决方案提案
- `ppt-layout-library/`：页面分区与布局模式
- `ppt-diagram-library/`：流程图、路线图、组织图等图解模式
- `ppt-visual-component-library/`：卡片、标签、箭头、状态标识等视觉组件
- `ppt-slide-type-library/`：完整页面类型
- `ppt-title-strategy/`：栏目标题、结论型标题与混合模式
- `ppt-quality-check/`：交付前检查
- `examples/`：场景 brief 和示例大纲

## 使用方法

1. 将本包中的 Skills 文件夹复制到项目仓库的 `skills/` 目录。
2. 阅读并调整各 `SKILL.md` 的触发条件，使其符合团队的工作方式。
3. 如果公司有正式的 PowerPoint 母版（`.potx`）、字体或配色标准，优先使用公司标准，并更新 `ppt-design-system/design-rules.md`。
4. 制作较大的演示文稿时，先让 AI 输出故事线和逐页大纲，再生成页面。
5. 生成后运行 `ppt-quality-check`，并实际检查导出的 PPTX 渲染效果。

## 推荐提示词

> 请为【受众】制作一份关于【主题】的 PowerPoint。目的：【汇报/决策/对齐/分析/提案】，语言：【语言】，页数或演讲时长：【要求】。请使用 `ppt-router`，应用统一 Design System，从 Slide Type Library 选择页面类型，根据内容选用 Layout Patterns 和 Diagram Patterns，并遵循 Title Strategy。先输出故事线和逐页大纲，再生成可编辑的 PPTX，最后执行质量检查。事实、假设、建议和待确认事项必须明确区分，不得编造数据。

## 重要说明

- 这些文件定义工作流程、设计规则和页面模式，本身不保证直接生成 `.pptx` 文件。实际生成需要支持 PowerPoint 的工具、Agent 工作流或项目脚本。
- 不同 Agent 对 Skills 的发现和调用方式可能不同；请按所用产品当前支持的格式调整 front matter 与目录结构。
- 本库借鉴通用的咨询式表达原则，不复制 McKinsey、BCG、Bain 或 Accenture 的专有模板、品牌标识或受版权保护的页面。
- 第三方模板、图标、字体和图片在复制到公司仓库前，必须确认授权许可。
- 交付前要核实数据、计算、来源、图表和 PPTX 的实际渲染。
