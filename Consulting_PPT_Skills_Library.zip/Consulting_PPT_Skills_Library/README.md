# Consulting PPT Skills Library

用于 GitHub Copilot 等支持仓库内 Skills 的 AI 助手的企业演示文稿设计与制作规范。目标是建立一套可复用、可维护、风格一致的原创咨询式 PPT 方法，而不是复制任何咨询公司的专有模板。

## 本次版本更新

本版本在原有 Skills 基础上，补充了常见咨询页面类型目录、页面选择路由和模板设计规则。重点覆盖：项目概要、方案比较、业务流程、现状与目标、建议与决策、问题拆解、实施路线图、进度报告、风险管理、项目治理、解决方案架构、KPI Dashboard、成本效益分析、数据流/接口映射、行动事项等。

## 包含内容

- `ppt-router/`：根据目的、受众和内容选择工作流程与页面类型
- `ppt-design-system/`：统一视觉系统、颜色、字体、间距和图表规范
- `ppt-title-strategy/`：栏目标题、结论型标题与混合模式
- `ppt-project-plan/`：项目计划、阶段、WBS、里程碑和依赖关系
- `ppt-status-report/`：项目进度、状态、偏差、风险和下一步行动
- `ppt-issue-analysis/`：问题定义、证据、根因和分析逻辑
- `ppt-solution-proposal/`：业务/IT 方案、架构、比较和实施路径
- `ppt-slide-type-library/`：页面类型选择规则与 15 类常见咨询页面目录
- `ppt-layout-library/`：页面分区与布局模式
- `ppt-diagram-library/`：流程图、路线图、泳道图、组织图、架构图等图解模式
- `ppt-visual-component-library/`：卡片、标签、箭头、状态标识等视觉组件
- `ppt-quality-check/`：内容、数据、版式、可读性和导出质量检查
- `examples/`：项目 brief、页面类型记录模板、状态报告大纲

## 15 类常见咨询页面

1. Executive Summary｜执行摘要
2. Project Overview｜项目概要
3. Option Comparison｜方案比较
4. Recommendation & Decision｜建议与决策
5. As-Is / To-Be｜现状与目标状态
6. Process Flow｜业务流程图
7. Issue Tree / Root Cause｜问题拆解与根因分析
8. Execution Roadmap｜实施路线图
9. Project Status Report｜项目进度报告
10. Risk & Mitigation｜风险与应对措施
11. Organization & Governance｜项目体制与治理
12. Solution Architecture｜解决方案架构
13. KPI Dashboard｜指标与绩效看板
14. Cost-Benefit / Business Case｜成本效益与商业论证
15. Data Flow / Interface Mapping｜数据流与接口映射
16. Action Items / Next Steps｜行动事项与下一步

以上是核心目录，不是限制。可根据业务需要组合或新增页面类型；一页应优先表达一个主要信息。

## 使用方法

1. 将 `skills/` 目录下的 Skills 复制到项目仓库对应位置；本 ZIP 中的 `ppt-*` 目录就是各 Skill 目录，可直接放入仓库的 `skills/` 下。
2. 阅读并调整各 `SKILL.md` 的触发条件，使其符合团队的工作方式。
3. 有公司正式 PowerPoint 母版（`.potx`）、字体或配色标准时，优先使用公司标准，并更新 `ppt-design-system/design-rules.md`。
4. 制作较大的演示文稿时，先输出故事线和逐页大纲，确认每页的受众、目的、结论、证据和页面类型，再生成页面。
5. 根据内容逻辑选择页面类型，不要只因视觉效果相似就套用模板。
6. 生成后运行 `ppt-quality-check`，并实际检查导出的 PPTX 渲染效果。

## 推荐提示词

> 请为【受众】制作一份关于【主题】的 PowerPoint。目的：【汇报/决策/对齐/分析/提案】，语言：【语言】，页数或演讲时长：【要求】。请使用 `ppt-router` 选择流程，应用 `ppt-design-system`，从 `ppt-slide-type-library/catalog.md` 为每页选择最适合的页面类型，并结合 `ppt-layout-library`、`ppt-diagram-library` 和 `ppt-visual-component-library`。先输出故事线和逐页大纲，再生成可编辑的 PPTX，最后执行 `ppt-quality-check`。事实、假设、建议和待确认事项必须明确区分，不得编造数据。

## 页面类型设计原则

- **内容逻辑优先于装饰**：先明确页面要回答的问题，再选布局。
- **结论先行**：分析与决策页面尽量使用可传达判断的标题；目录、体制图、流程说明等可使用栏目标题。
- **一致的视觉系统**：统一字体、颜色、间距、线宽、圆角和状态含义。
- **原生可编辑**：优先使用 PowerPoint 原生文本、形状、表格和图表；避免把整页做成不可编辑图片。
- **数据有依据**：评分、成本、KPI、状态、风险等级和日期不得凭空补齐；缺失时标记待确认。
- **适量信息**：一页一个主要信息；复杂内容拆页，不要将多个不同关系模型硬塞进一页。
- **模板与设计系统分离**：页面类型定义内容结构，布局库定义空间组织，图解库定义关系表达，设计系统定义视觉规范。

## 重要说明

- 这些文件定义工作流程、设计规则和页面模式，本身不保证直接生成 `.pptx` 文件。实际生成需要支持 PowerPoint 的工具、Agent 工作流或项目脚本。
- 不同 Agent 对 Skills 的发现和调用方式可能不同；请按所用产品当前支持的格式调整 front matter 与目录结构。
- 本库借鉴通用的咨询式表达原则，不复制 McKinsey、BCG、Bain 或 Accenture 的专有模板、品牌标识或受版权保护的页面。
- 第三方模板、图标、字体和图片在复制到公司仓库前，必须确认授权许可；“免费”不等于可以无限制商业使用或重新分发。
- 交付前要核实数据、计算、来源、图表和 PPTX 的实际渲染。
