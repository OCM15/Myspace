# DB Evidence Contract

This contract allows Devin without DB access to consume DB verification performed by Copilot, CI, or an internal test server.

## Minimal Result

```json
{
  "testCaseId": "TC-001",
  "status": "PASS",
  "database": "ORACLE",
  "insertCount": 1,
  "updateCount": 0,
  "deleteCount": 0,
  "businessDifference": []
}
```

## Failure

```json
{
  "testCaseId": "TC-002",
  "status": "FAIL",
  "database": "SYBASE",
  "businessDifference": [
    {
      "table": "TRANSACTION",
      "key": "10001",
      "field": "amount",
      "legacy": 1000000,
      "new": 999999
    }
  ]
}
```

## Pending

```json
{
  "testCaseId": "TC-003",
  "status": "DB_VERIFICATION_PENDING"
}
```

Pending is not PASS.

## Security

Do not include:
- passwords
- connection strings
- unrelated customer data
- unnecessary full-table exports

Return only information required for migration verification.
