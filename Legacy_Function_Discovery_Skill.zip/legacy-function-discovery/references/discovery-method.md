# Discovery Method

先收集 Evidence，再写 Functional Model。

推荐 Evidence 表：
| ID | Evidence | Observation | Classification | Confidence |
|---|---|---|---|---|
| E001 | SQL | SELECT TRADE_INFO | BUSINESS_DATA | High |
| E002 | File writer | creates complete.dat | TECHNICAL_TRIGGER | Medium |
| E003 | watcher | starts downstream batch | TECHNICAL_TRIGGER | High |

搜索入口、caller/callee、SQL、table、file、API、MQ、exception、transaction、configuration、status、scheduler、batch。

不要仅靠 call graph 判断业务意义；同一个 utility 可能是业务输出、技术控制或临时处理。
