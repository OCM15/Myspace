# Execution Matrix

| Test Area | Devin No DB | Copilot With DB |
|---|---|---|
| Source inspection | YES | YES |
| Test case generation | YES | YES |
| UI test | YES* | YES* |
| Workflow test | YES* | YES* |
| API test | YES* | YES* |
| Validation test | YES* | YES* |
| Authorization test | YES* | YES* |
| Sybase access | NO | YES |
| Oracle access | NO | YES |
| DB snapshot | NO | YES |
| DB comparison | Consume evidence | YES |
| DB SQL generation | Can generate, cannot execute | YES |
| DB evidence analysis | YES | YES |
| Final migration report | YES | YES |

*Environment must expose the application/browser/API to the tool.

## PASS Rule

Overall PASS requires all mandatory layers to pass.

If DB verification is mandatory and Devin has no DB evidence:

DB_VERIFICATION_PENDING

Do not convert it to PASS.
