# Slide Type Selection Examples｜页面类型选择示例

## 示例 1：比较两个 Java 系统刷新方案
- 主要问题：应选择原地升级还是迁移到新框架？
- 推荐页面：Executive Summary → Option Comparison → Recommendation & Decision → Solution Architecture → Execution Roadmap → Risk & Mitigation。
- 注意：统一评价标准；说明业务功能保持不变、数据库约束、迁移风险和回退策略；缺少数据时标记待评估。

## 示例 2：解释跨部门审批流程
- 主要问题：请求由谁处理、如何审批、拒绝后如何返回？
- 推荐页面：Process Flow；如涉及多个部门或系统，使用 Swimlane。
- 注意：标明判断条件、输入输出、异常/退回路径及责任角色。

## 示例 3：项目月度汇报
- 主要问题：项目是否按计划推进，管理层需要采取什么行动？
- 推荐页面：Executive Summary → Project Status Report → Risk & Mitigation → Action Items。
- 注意：注明报告日期；计划和实际分开；每项行动有负责人和期限。

## 示例 4：提出业务系统投资申请
- 主要问题：为什么要投资，预期收益是否值得成本？
- 推荐页面：As-Is / To-Be → Cost-Benefit / Business Case → Option Comparison → Recommendation & Decision。
- 注意：说明估算期间、假设、成本来源和收益计算口径。

## 示例 5：说明批处理与 MQ 接口
- 主要问题：数据如何从源头传到目标，目标系统故障时如何处理？
- 推荐页面：Data Flow / Interface Mapping → Process Flow → Risk & Mitigation → Execution Roadmap（若涉及改造计划）。
- 注意：区分业务必要的数据流和纯技术触发机制；标注重试、超时、死信/错误记录等设计（仅在实际方案中确认后填写）。
