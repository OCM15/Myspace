# Devin No-DB Execution Skill

## Environment

Devin has no direct Sybase/Oracle access.

## Devin Can

- inspect source and tests
- create test scenarios
- run browser tests
- run API tests
- execute workflow tests
- compare legacy/new UI/API results
- consume DB evidence
- analyze failures
- generate reports

## Devin Cannot

- connect to Sybase
- connect to Oracle
- invent DB evidence
- claim DB PASS without DB evidence
- store DB credentials

## DB Evidence Contract

Expected artifact:

```json
{
  "testCaseId": "TC-001",
  "database": "ORACLE",
  "status": "PASS",
  "insertCount": 1,
  "updateCount": 0,
  "deleteCount": 0,
  "businessDifference": []
}
```

If unavailable:

```json
{
  "testCaseId": "TC-001",
  "status": "DB_VERIFICATION_PENDING"
}
```

## Recommended Workflow

1. Run UI test.
2. Run API test.
3. Save evidence.
4. Read DB evidence artifact.
5. Combine results.
6. Report PASS only if required DB evidence exists.
7. Otherwise report DB_VERIFICATION_PENDING.
