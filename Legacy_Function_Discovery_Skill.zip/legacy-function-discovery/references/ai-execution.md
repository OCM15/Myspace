# AI Execution Guide

## Devin
若无DB权限：做静态源码/配置分析，生成 DB/File/I-F specification；不得声称已完成 runtime DB verification。

## GitHub Copilot
若有Sybase/Oracle权限：可验证 table/column、SQL、cardinality、update/delete condition，并输出独立 DB evidence。

静态 discovery 与 runtime verification 是不同证据类别。

```text
Devin → Source Discovery → Functional Model
Copilot → DB Verification → DB Evidence
Both → Functional Specification → Review → Migration Tests
```
