# External Interface

记录 business purpose、sender/receiver、trigger、request/message、field mapping、timeout、retry、response/ack、error mapping、transaction relationship、downstream purpose。

分开：
Business contract = 必须发生什么
Current transport = 现在如何实现
