# Example Outline — Monthly Status Report

1. Overall Status — takeaway title summarizing evidence-based project health
2. Progress Overview — label title; baseline vs forecast
3. Milestones — label title; planned and actual dates
4. Key Issues — label title; impact, owner, due date, mitigation
5. Decisions Required — takeaway title where a supported recommendation exists
6. Next Month's Plan — label title; workstreams, owners, expected outputs

Use Hybrid title strategy. Never invent RAG status, dates, progress percentages, or decisions.
