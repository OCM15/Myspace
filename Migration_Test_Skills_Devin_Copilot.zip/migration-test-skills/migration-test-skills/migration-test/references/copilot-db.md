# GitHub Copilot DB Execution Skill

## Environment

Copilot operates in an approved development/test environment with Sybase and Oracle access.

## Responsibilities

- generate DB test SQL
- generate DB comparison code
- execute approved queries
- create JUnit/integration tests
- collect DB evidence
- correlate DB results with UI/API tests

## Database Rules

Prefer:
- read-only SELECT for comparison
- test schemas
- transaction rollback for isolated tests
- explicit test data
- business-key based comparison

Avoid:
- production data
- destructive SQL without explicit authorization
- credential hardcoding
- broad SELECT * when unnecessary

## Before/After

Capture:

BEFORE
  -> relevant business records

EXECUTE
  -> UI/API/business operation

AFTER
  -> relevant business records

COMPARE
  -> INSERT/UPDATE/DELETE/business values

## Sybase / Oracle

DB-specific SQL may differ.

Do not require identical SQL.

The business result must be equivalent.

Example:

```text
Sybase:
transaction.status = ACTIVE

Oracle:
transaction.status = ACTIVE

Business result:
EQUAL
```

## Evidence

Generate a sanitized result:

```json
{
  "testCaseId": "TC-001",
  "status": "PASS",
  "database": "ORACLE",
  "businessDifference": []
}
```
