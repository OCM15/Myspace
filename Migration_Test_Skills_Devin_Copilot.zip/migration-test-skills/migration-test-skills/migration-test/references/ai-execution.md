# AI Execution Instructions

## Phase 1: Inventory

Read:
- function matrix
- screen contracts
- existing tests
- API definitions
- known business tables

Create missing test cases.

## Phase 2: Legacy Baseline

Capture:
- screen behavior
- validation
- workflow
- API result
- DB result when available

## Phase 3: New System

Execute the same scenarios.

## Phase 4: Compare

Compare:
- UI semantics
- workflow
- validation
- authorization
- API
- DB business result

## Phase 5: Investigate

Every difference must be:
- reproduced
- evidenced
- classified

Do not modify expected results automatically.

## Phase 6: Report

Report:
- coverage
- pass/fail
- DB verification status
- differences
- evidence
- unresolved items

## Environment-specific behavior

If running under Devin:
- do not access DB
- consume DB evidence
- mark missing DB evidence as DB_VERIFICATION_PENDING

If running under Copilot:
- use approved Sybase/Oracle access
- execute DB tests
- produce DB evidence
