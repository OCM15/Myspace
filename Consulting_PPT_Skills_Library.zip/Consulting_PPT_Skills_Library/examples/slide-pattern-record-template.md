# Slide Pattern Record Template

## Pattern name
- English name:
- Japanese/Chinese name:
- Pattern type: Layout / Diagram / Component / Slide Type

## Intended use
- What question does this pattern answer?
- Best-fit scenarios:
- Not suitable when:

## Required inputs
- Required fields:
- Optional fields:
- Data/source expectations:

## Structure
- Canvas / grid:
- Main regions:
- Shape/component mapping:
- Reading order:
- Connectors / relationship semantics:

## Title strategy
- Label-title / Takeaway-title / Hybrid:
- Example titles:

## Visual rules
- Typography:
- Color semantics:
- Spacing/alignment:
- Density limit:

## Quality checklist
- Common errors:
- Accessibility/readability:
- Editability:
- Source/license notes:
