# Independence Review

## Source-Code Blackout Test

假设源码不可用，检查是否还能回答：
1. What does it do?
2. Who can execute it?
3. Inputs/outputs?
4. Validation?
5. Business decisions?
6. DB read/write?
7. File read/write?
8. External systems?
9. Downstream trigger?
10. Failure behavior?
11. What must remain unchanged?
12. What is merely legacy implementation?

质量门：
- Completeness
- Business clarity
- Resource explicitness
- Classification
- Reimplementation
- Testability
- Traceability
