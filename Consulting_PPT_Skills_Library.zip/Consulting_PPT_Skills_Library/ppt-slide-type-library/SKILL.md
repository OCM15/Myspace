---
name: ppt-slide-type-library
description: 根据页面目的选择咨询式页面类型，定义必需内容、布局结构、标题策略与完整性检查。
---

# Slide Type Library Skill

## 目标
将页面的业务表达逻辑与视觉样式分离。页面类型决定“要表达什么、必须包含什么”；布局库决定空间组织；图解库决定关系表达；Design System 决定视觉规则。

## 使用流程
1. 为每页写出一句话目的：听众看完后需要理解什么、相信什么或决定什么？
2. 从 `catalog.md` 选择最接近的页面类型。
3. 确认所需输入、证据、关键字段和缺失信息。
4. 选择合适的布局、图解与视觉组件。
5. 选择标题模式：栏目标题、结论型标题或混合型。
6. 按页面类型的检查项验证完整性。
7. 若没有合适类型，先组合现有模式；只有在确实存在新需求时才新增类型，并记录其用途和规则。

## 核心目录
完整目录与每类页面的内容、布局和检查项见 `catalog.md`。主要类型包括：
- Executive Summary
- Project Overview
- Option Comparison
- Recommendation & Decision
- As-Is / To-Be
- Process Flow
- Issue Tree / Root Cause
- Execution Roadmap
- Project Status Report
- Risk & Mitigation
- Organization & Governance
- Solution Architecture
- KPI Dashboard
- Cost-Benefit / Business Case
- Data Flow / Interface Mapping
- Action Items / Next Steps

## 选择规则
- 比较方案时优先用比较矩阵；解释步骤时优先用流程图；展示时间顺序时优先用时间轴/路线图；展示数据趋势时优先用图表。
- 需要管理层决策时，使用 Recommendation & Decision 或 Executive Summary，而不是只给一张信息表。
- IT 方案可组合 Solution Architecture、Data Flow、Option Comparison 和 Execution Roadmap，但每页仍应有单一主旨。
- 项目概要页应覆盖目标、范围、交付物、时间和成功标准；状态报告应覆盖状态、偏差、风险和下一步。
- 标题、视觉元素与内容之间必须一致；不得用装饰图形替代业务关系。
- 必要信息缺失时明确标记“待确认”，不得编造。

## 完整性检查
- 页面目的是否清楚？
- 标题是否表达页面内容，必要时是否给出结论？
- 页面类型是否匹配信息关系？
- 必要字段、证据、限制和异常路径是否遗漏？
- 是否将事实、假设、估算、建议区分清楚？
- 是否避免过度拥挤，并保持 PowerPoint 元素可编辑？
