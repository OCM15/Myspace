# Legacy Function Discovery Skill

用于从 Legacy Source Code 完整逆向整理单个系统功能，生成不依赖原始源码即可理解、重新实现和测试的 Functional Specification。

核心原则：
- Preserve business behavior, not implementation.
- 不因源码中存在某个操作，就自动认定它是业务需求。
- DB/File/MQ/API 等资源必须明确到资源、字段、条件、Mapping、异常处理。
- 明确区分 BUSINESS_* 与 TECHNICAL_TRIGGER / TECHNICAL_CONTROL / IMPLEMENTATION_DETAIL。
- 信息不足时使用 UNKNOWN / REQUIRES_HUMAN_CONFIRMATION，不猜测。
- 最终设计书必须通过 Source-Code Blackout Test。

目录：
```text
skills/
└── legacy-function-discovery/
    ├── SKILL.md
    ├── references/
    │   ├── discovery-method.md
    │   ├── business-vs-implementation.md
    │   ├── database-specification.md
    │   ├── file-io-specification.md
    │   ├── external-interface.md
    │   ├── exception-analysis.md
    │   ├── independence-review.md
    │   └── ai-execution.md
    └── templates/
        ├── function-spec.yaml
        ├── resource-inventory.yaml
        ├── business-implementation-classification.yaml
        ├── traceability-matrix.yaml
        └── review-checklist.yaml
```

与 Migration Test Skill：
Legacy Source → Discovery → function-spec.yaml → Human Review → Migration Test → Legacy/New Comparison
