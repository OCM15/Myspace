# Migration Test Skills

用于旧系统 -> 新系统迁移时验证“用户功能不变”。

本 Skill 针对两种 AI 工作环境设计：

1. Devin：没有 DB 环境
   - 可以执行 UI / API / workflow 测试
   - 不直接访问 DB
   - DB 验证依赖外部提供的 DB evidence / DB comparison result
   - 不允许因为无法访问 DB 就跳过 DB 测试

2. GitHub Copilot：有 DB 环境
   - 可以在项目允许的范围内访问 Sybase / Oracle
   - 可以执行 DB snapshot / query / comparison
   - 可以辅助生成 SQL、JUnit、integration test
   - 必须遵守项目 DB 权限和安全规范

推荐顺序：

UI -> Workflow -> API -> DB -> Legacy/New Equivalence -> Report
