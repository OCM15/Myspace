# Migration Test Skill

## 1. Purpose

Verify that a migrated application preserves the business behavior of the legacy application.

Migration may change:
- Java framework
- library versions
- application architecture
- internal implementation
- UI layout/style
- API implementation
- DB access implementation

Migration must not unintentionally change:
- business functions
- business rules
- validation
- calculations
- authorization
- user workflow
- business-relevant DB results
- transaction behavior
- error handling

The legacy application is the behavioral baseline unless a legacy behavior is explicitly marked for review.

---

## 2. Fundamental Rule

Do not prove equivalence by comparing source code.

Compare observable behavior:

Legacy input -> Legacy result
New input    -> New result

Default comparison: EXACT.

Never weaken an assertion simply to make the migration pass.

---

## 3. Two Execution Modes

### MODE A: DEVIN_NO_DB

Assumptions:
- Devin cannot access Sybase or Oracle.
- Devin can execute UI/API/workflow tests if the environment is available.
- DB verification is performed by an external DB-capable runner, CI job, human operator, or evidence package.

Devin responsibilities:
- discover functions
- create test cases
- execute UI/workflow/API tests
- compare legacy/new observable behavior
- consume DB evidence
- analyze differences
- generate reports

Devin must NOT:
- invent DB results
- claim DB equivalence without evidence
- skip DB verification silently
- request or store DB credentials

Expected DB evidence formats:
- db-result.json
- db-diff.json
- CSV/TSV evidence
- approved SQL result files
- CI test artifacts

### MODE B: COPILOT_DB

Assumptions:
- GitHub Copilot works in a project environment with approved Sybase and Oracle access.
- The developer/test environment has the required DB permissions.

Copilot responsibilities:
- generate DB test SQL
- execute or assist with approved DB tests
- compare Sybase/Oracle business results
- generate JUnit/integration tests
- create DB evidence
- connect DB results with UI/API test cases

Copilot must still:
- use only approved schemas/tables
- avoid destructive SQL unless explicitly authorized
- never expose credentials
- prefer read-only comparison queries
- preserve reproducible test data

---

## 4. Test Layers

1. UI structure
2. UI input/validation
3. User workflow/navigation
4. Authorization
5. API/service
6. DB business result
7. Legacy/New equivalence
8. E2E

UI style is not the default equivalence target.

---

## 5. UI Equivalence

The new UI may change:
- layout
- CSS
- color
- font
- component type
- button position
- label wording

The new UI must preserve:
- available business operations
- required fields
- validation behavior
- navigation
- action semantics
- permission behavior
- success/failure behavior

Prefer semantic selectors:

```html
<button
  data-testid="transaction-register"
  data-action="TRANSACTION_CREATE">
  保存
</button>
```

Do not use pixel comparison as the primary migration oracle.

---

## 6. Workflow Equivalence

For every critical user function define:

1. Open screen
2. Input/select data
3. Trigger action
4. Validate
5. Confirm/cancel
6. Navigate
7. Verify result

Compare the workflow semantics between legacy and new.

Example:

Legacy:
Register -> Confirm -> Success

New:
Save -> Confirm -> Success

This can be equivalent if the business action/result is equivalent.

---

## 7. Validation Tests

For each important input:
- normal
- empty
- required
- invalid format
- min
- max
- boundary
- invalid code
- duplicate
- unauthorized

Compare:
- whether accepted/rejected
- validation message category
- whether DB operation occurs
- transaction behavior

---

## 8. Authorization Tests

For each user group:
- screen access
- button visibility
- button enabled/disabled
- direct API authorization

Frontend hiding is never sufficient.

Backend authorization must also be tested.

---

## 9. Legacy/New Equivalence

For every test case:

1. Prepare equivalent initial conditions.
2. Execute legacy.
3. Capture observable result.
4. Reset.
5. Execute new.
6. Capture observable result.
7. Normalize approved dynamic fields.
8. Compare.
9. Record every difference.
10. Classify the difference.

Never silently accept a difference.

---

## 10. DB Verification

### Devin

Devin has no DB access.

Therefore DB testing must use one of:

A. external DB test runner
B. CI job
C. manually generated approved evidence
D. test API exposing sanitized DB comparison results

Devin consumes evidence such as:

```json
{
  "testCaseId": "TC-001",
  "status": "PASS",
  "insertCount": 1,
  "updateCount": 0,
  "deleteCount": 0,
  "businessDifference": []
}
```

If evidence is missing:

```text
DB_VERIFICATION_PENDING
```

Do NOT report PASS.

### Copilot

Copilot may directly execute approved DB tests.

For Sybase and Oracle:
- identify business tables
- capture before state
- execute operation
- capture after state
- compare business columns
- verify INSERT/UPDATE/DELETE
- verify commit/rollback

Do not require identical SQL or execution plan.

---

## 11. Dynamic Values

Potential dynamic fields:
- UUID
- timestamp
- session ID
- request ID
- sequence
- generated ID
- server hostname

Only explicitly configured fields may be normalized or ignored.

Default = EXACT.

Every IGNORE/NORMALIZE rule needs:
- reason
- owner/approval
- scope

---

## 12. Failure Classification

Use one of:

BUSINESS_REGRESSION
VALIDATION_REGRESSION
AUTHORIZATION_REGRESSION
CALCULATION_REGRESSION
DATABASE_REGRESSION
TRANSACTION_REGRESSION
ERROR_HANDLING_REGRESSION
UI_BEHAVIOR_REGRESSION
EXPECTED_DIFFERENCE
LEGACY_BEHAVIOR_REVIEW
TEST_DATA_PROBLEM
ENVIRONMENT_PROBLEM
DB_VERIFICATION_PENDING

---

## 13. AI Rules

AI must:
1. reuse project conventions
2. keep tests deterministic
3. never modify production code merely to make tests pass
4. never change legacy expected results because new results differ
5. never delete failing tests without approval
6. never weaken assertions without approval
7. preserve evidence
8. use semantic UI selectors
9. clearly distinguish verified facts from unavailable evidence
10. never invent DB results

---

## 14. Definition of Done

Critical migration testing is complete only when:
- critical functions are covered
- critical workflows are covered
- validation is covered
- authorization is covered
- Legacy/New equivalence passes
- DB results are verified or explicitly waived by project owner
- all differences are classified
- no unexplained critical regression remains

A high test-pass percentage is not sufficient.
